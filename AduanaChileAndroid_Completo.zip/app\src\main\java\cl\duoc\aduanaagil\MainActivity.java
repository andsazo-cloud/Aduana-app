package cl.duoc.aduanaagil;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final String USER = "funcionario";
    private static final String PASS = "aduana2026";

    private final ArrayList<String> actions = new ArrayList<>();
    private LinearLayout root;
    private SharedPreferences prefs;
    private boolean darkMode;
    private int primary;
    private int accent;
    private int background;
    private int surface;
    private int textMain;
    private int textMuted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("aduana_agil", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        applyPalette();
        showLogin();
    }

    private void applyPalette() {
        primary = darkMode ? Color.rgb(90, 169, 230) : Color.rgb(0, 59, 112);
        accent = darkMode ? Color.rgb(255, 107, 107) : Color.rgb(214, 40, 40);
        background = darkMode ? Color.rgb(8, 19, 31) : Color.rgb(245, 247, 250);
        surface = darkMode ? Color.rgb(16, 34, 56) : Color.WHITE;
        textMain = darkMode ? Color.rgb(242, 246, 250) : Color.rgb(16, 32, 51);
        textMuted = darkMode ? Color.rgb(180, 193, 207) : Color.rgb(92, 107, 122);
        getWindow().setStatusBarColor(darkMode ? Color.rgb(7, 27, 47) : Color.rgb(0, 41, 79));
        getWindow().setNavigationBarColor(darkMode ? Color.rgb(7, 27, 47) : Color.rgb(0, 41, 79));
    }

    private void startScreen() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(background);
        scroll.addView(root);
        setContentView(scroll);
    }

    private void showLogin() {
        startScreen();
        addSpace(28);
        TextView badge = label("Servicio Nacional de Aduanas", 14, true, primary);
        badge.setGravity(Gravity.CENTER);
        root.addView(badge);
        TextView title = label("Aduana Ágil", 34, true, textMain);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = label("Gestión fronteriza terrestre para documentación, control y trazabilidad.", 16, false, textMuted);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(dp(8), dp(8), dp(8), dp(18));
        root.addView(subtitle);

        LinearLayout card = card();
        TextView access = label("Inicio de sesión profesional", 22, true, textMain);
        card.addView(access);
        TextView hint = label("Ingresa con una cuenta habilitada para operar los módulos de Aduanas, SAG y PDI.", 14, false, textMuted);
        card.addView(hint);
        EditText user = input("Usuario");
        EditText pass = input("Clave");
        pass.setInputType(0x00000081);
        card.addView(user);
        card.addView(pass);
        Button login = button("Ingresar al sistema", primary);
        login.setOnClickListener(v -> {
            hideKeyboard(pass);
            if (USER.equals(user.getText().toString().trim()) && PASS.equals(pass.getText().toString().trim())) {
                addAction("Inicio de sesión de usuario habilitado");
                showHome();
            } else {
                Toast.makeText(this, "Credenciales inválidas. Usa funcionario / aduana2026", Toast.LENGTH_LONG).show();
            }
        });
        card.addView(login);
        TextView demo = label("Demo: funcionario / aduana2026", 13, false, textMuted);
        demo.setGravity(Gravity.CENTER);
        card.addView(demo);
        root.addView(card);
    }

    private void showHome() {
        startScreen();
        header("Panel operativo", "Accesos rápidos para reducir esperas y completar trámites antes de ventanilla.");
        LinearLayout stats = card();
        stats.addView(label("Estado del día", 20, true, textMain));
        stats.addView(label("Prechequeos completados: " + Math.max(3, actions.size() + 2), 15, false, textMuted));
        stats.addView(label("Tiempo estimado por trámite digital: 6 a 12 min", 15, false, textMuted));
        stats.addView(label("Última acción: " + lastAction(), 15, false, textMuted));
        root.addView(stats);

        menuButton("Trámites y documentación", "Menores, vehículos, SAG/PDI e integración fronteriza", v -> showProcedures());
        menuButton("Reportes estadísticos", "Ingresos, egresos, vehículos y alertas", v -> showReports());
        menuButton("Ayuda y requisitos", "Documentos exigidos por Aduanas", v -> showHelp());
        menuButton("Configuración", "Tema claro/oscuro y deshacer acción", v -> showSettings());
        menuButton("Cerrar sesión", "Volver al inicio seguro", v -> {
            addAction("Cierre de sesión");
            showLogin();
        });
    }

    private void showProcedures() {
        startScreen();
        header("Trámites", "Completa datos antes de llegar a ventanilla para agilizar el cruce.");
        procedureCard("Menores de edad", "Valida cédula/pasaporte y autorización notarial cuando corresponda.", "Registro de documentación de menor");
        procedureCard("Vehículos motorizados", "Prepara salida/admisión temporal por hasta 180 días.", "Registro de vehículo motorizado");
        procedureCard("Declaración SAG/PDI", "Control de alimentos, mascotas, productos animales o vegetales y revisión policial.", "Declaración SAG/PDI completada");
        procedureCard("Integración fronteriza", "Consulta datos entre Chile y Argentina para mejorar trazabilidad.", "Consulta integrada fronteriza");
        navHome();
    }

    private void procedureCard(String title, String description, String actionName) {
        LinearLayout c = card();
        c.addView(label(title, 20, true, textMain));
        c.addView(label(description, 14, false, textMuted));
        EditText rut = input("RUN / Pasaporte");
        EditText detail = input("Detalle del trámite");
        c.addView(rut);
        c.addView(detail);
        Button save = button("Guardar prechequeo", primary);
        save.setOnClickListener(v -> {
            if (rut.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "Ingresa RUN o pasaporte.", Toast.LENGTH_SHORT).show();
                return;
            }
            addAction(actionName + " - " + rut.getText().toString().trim());
            Toast.makeText(this, "Prechequeo guardado. Puedes deshacerlo desde Configuración.", Toast.LENGTH_LONG).show();
            rut.setText("");
            detail.setText("");
        });
        c.addView(save);
        root.addView(c);
    }

    private void showReports() {
        startScreen();
        header("Reportes", "Resumen automatizado para apoyar decisiones y detectar cuellos de botella.");
        LinearLayout c = card();
        c.addView(label("Indicadores operativos", 21, true, textMain));
        c.addView(label("Ingresos de personas: 1.284", 16, false, textMuted));
        c.addView(label("Egresos de personas: 1.106", 16, false, textMuted));
        c.addView(label("Vehículos registrados: 438", 16, false, textMuted));
        c.addView(label("Declaraciones SAG/PDI: 312", 16, false, textMuted));
        c.addView(label("Alertas por documentación incompleta: 27", 16, false, accent));
        Button generate = button("Generar resumen del día", primary);
        generate.setOnClickListener(v -> {
            addAction("Generación de reporte estadístico");
            showMessage("Reporte generado", "Resumen listo. Puedes exportarlo como PDF o archivo compatible con Excel.");
        });
        c.addView(generate);
        Button excel = button("Exportar Excel compatible (.csv)", primary);
        excel.setOnClickListener(v -> exportCsv());
        c.addView(excel);
        Button pdf = button("Exportar PDF", accent);
        pdf.setOnClickListener(v -> exportPdf());
        c.addView(pdf);
        root.addView(c);
        navHome();
    }

    private void showHelp() {
        startScreen();
        header("Ayuda", "Requisitos principales para pasajeros y funcionarios.");
        helpItem("Menores de edad", "Cédula o pasaporte vigente. Si viaja sin ambos padres, autorización notarial o autorización del Juzgado de Familia.");
        helpItem("Alimentos y productos SAG", "Toda persona debe declarar productos animales o vegetales mediante declaración jurada SAG/Aduanas.");
        helpItem("Vehículo desde Chile a Argentina", "Completar Salida y Admisión Temporal de Vehículos Acuerdo Chileno Argentino. Plazo general: 180 días.");
        helpItem("Vehículo desde Argentina a Chile", "Documento emitido por Aduana Argentina y reconocido por Aduana chilena. Plazo general: 180 días.");
        helpItem("Mascotas", "Declaración jurada ante SAG y Aduanas. Menores de 18 años deben hacerlo con su representante.");
        navHome();
    }

    private void showSettings() {
        startScreen();
        header("Configuración", "Personaliza la experiencia y corrige la última operación si fue necesario.");
        LinearLayout c = card();
        c.addView(label("Apariencia", 21, true, textMain));
        c.addView(label("Tema actual: " + (darkMode ? "Oscuro" : "Claro"), 15, false, textMuted));
        Button theme = button(darkMode ? "Cambiar a modo claro" : "Cambiar a modo oscuro", primary);
        theme.setOnClickListener(v -> {
            darkMode = !darkMode;
            prefs.edit().putBoolean("dark_mode", darkMode).apply();
            addAction("Cambio de tema a " + (darkMode ? "oscuro" : "claro"));
            applyPalette();
            showSettings();
        });
        c.addView(theme);
        Button undo = button("Deshacer última acción", accent);
        undo.setOnClickListener(v -> undoLastAction());
        c.addView(undo);
        c.addView(label("Última acción registrada: " + lastAction(), 14, false, textMuted));
        root.addView(c);
        navHome();
    }

    private void helpItem(String title, String body) {
        LinearLayout c = card();
        c.addView(label(title, 19, true, textMain));
        c.addView(label(body, 15, false, textMuted));
        root.addView(c);
    }

    private void menuButton(String title, String subtitle, View.OnClickListener listener) {
        LinearLayout c = card();
        c.setOnClickListener(listener);
        c.addView(label(title, 20, true, textMain));
        c.addView(label(subtitle, 14, false, textMuted));
        TextView arrow = label("Abrir", 14, true, primary);
        arrow.setGravity(Gravity.RIGHT);
        c.addView(arrow);
        root.addView(c);
    }

    private void header(String title, String subtitle) {
        TextView brand = label("Aduana Ágil", 14, true, primary);
        root.addView(brand);
        TextView h = label(title, 30, true, textMain);
        root.addView(h);
        TextView s = label(subtitle, 15, false, textMuted);
        s.setPadding(0, 0, 0, dp(12));
        root.addView(s);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackgroundColor(surface);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(10));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView label(String text, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.12f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(false);
        e.setMinLines(1);
        e.setTextColor(textMain);
        e.setHintTextColor(textMuted);
        e.setBackgroundColor(darkMode ? Color.rgb(23, 45, 72) : Color.rgb(238, 243, 248));
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(10), 0, 0);
        e.setLayoutParams(lp);
        return e;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setBackgroundColor(color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(12), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void navHome() {
        Button home = button("Volver al menú principal", primary);
        home.setOnClickListener(v -> showHome());
        root.addView(home);
    }

    private void addAction(String action) {
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        actions.add(time + " - " + action);
    }

    private String lastAction() {
        if (actions.isEmpty()) return "Sin acciones recientes";
        return actions.get(actions.size() - 1);
    }

    private void undoLastAction() {
        if (actions.isEmpty()) {
            Toast.makeText(this, "No hay acciones para deshacer.", Toast.LENGTH_SHORT).show();
            return;
        }
        String removed = actions.remove(actions.size() - 1);
        Toast.makeText(this, "Acción deshecha: " + removed, Toast.LENGTH_LONG).show();
        showSettings();
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void exportCsv() {
        File out = new File(getExternalFilesDir(null), "reporte_aduana_agil.csv");
        String csv = "Indicador,Valor\n"
                + "Ingresos de personas,1284\n"
                + "Egresos de personas,1106\n"
                + "Vehiculos registrados,438\n"
                + "Declaraciones SAG/PDI,312\n"
                + "Alertas por documentacion incompleta,27\n";
        try (FileOutputStream stream = new FileOutputStream(out)) {
            stream.write(csv.getBytes());
            addAction("Exportación de reporte Excel compatible");
            showMessage("Archivo Excel generado", "Se guardó el reporte compatible con Excel en:\n" + out.getAbsolutePath());
        } catch (IOException e) {
            showMessage("No se pudo exportar", e.getMessage());
        }
    }

    private void exportPdf() {
        File out = new File(getExternalFilesDir(null), "reporte_aduana_agil.pdf");
        PdfDocument doc = new PdfDocument();
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(595, 842, 1).create());
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(primary);
        paint.setTextSize(24);
        paint.setFakeBoldText(true);
        canvas.drawText("Reporte Aduana Ágil", 48, 70, paint);
        paint.setFakeBoldText(false);
        paint.setColor(textMain);
        paint.setTextSize(15);
        String[] rows = {
                "Ingresos de personas: 1.284",
                "Egresos de personas: 1.106",
                "Vehículos registrados: 438",
                "Declaraciones SAG/PDI: 312",
                "Alertas por documentación incompleta: 27"
        };
        int y = 120;
        for (String row : rows) {
            canvas.drawText(row, 48, y, paint);
            y += 32;
        }
        doc.finishPage(page);
        try (FileOutputStream stream = new FileOutputStream(out)) {
            doc.writeTo(stream);
            addAction("Exportación de reporte PDF");
            showMessage("PDF generado", "Se guardó el reporte en:\n" + out.getAbsolutePath());
        } catch (IOException e) {
            showMessage("No se pudo exportar", e.getMessage());
        } finally {
            doc.close();
        }
    }

    private void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private void addSpace(int dp) {
        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(1, dp(dp)));
        root.addView(space);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
