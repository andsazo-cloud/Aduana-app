# Aduana Ágil

Aplicación Android desarrollada para el caso de estudio del Examen Final Transversal de Ingeniería de Software.

## Funcionalidades incluidas

- Inicio de sesión con cuenta habilitada de demostración.
- Menú principal simple con accesos a trámites, reportes, ayuda, configuración y cierre de sesión.
- Formularios para menores de edad, vehículos, declaración SAG/PDI e integración fronteriza.
- Generación de resúmenes estadísticos en pantalla y exportación a PDF o archivo compatible con Excel.
- Modo claro, modo oscuro y modo automático del sistema.
- Opción para deshacer la última acción registrada.
- Ayuda contextual con documentos requeridos por Aduanas.
- Diseño con colores institucionales inspirados en Aduanas de Chile.

## Credenciales de prueba

- Usuario: `funcionario`
- Clave: `aduana2026`

## Compilación

El proyecto está preparado para compilar con Android Gradle Plugin 8.7.3 y Gradle 8.9.

```powershell
gradle assembleDebug
```

El APK de entrega queda en `APK/AduanaAgil-debug.apk` y también se copia a la carpeta `outputs`.
